
export function getArtistSeeds() {
  return ["4ySoYPWIFtEoOiIMhBK45k", "0SgQK24WzZf2pXBXYqHJYF"];
}


export function getAlbumSeeds() {
  return ["0h7eWdIjGnItMJ7aO83egh", "1Nejskv080HulTwcWnNPUr", "4otrsPPgsDZ27FgN2bR8ty"];
}

export function getGenreSeeds() {
  return ["indie", "techno", "bossanova"];
}