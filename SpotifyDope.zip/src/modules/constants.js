
export const userId = "313koscxpu5jngauqujl4hwspjjq";
export const clientId = "bf913c95feeb4ab993b0b6069f65bee3";
export const clientSecret = "726358cc26e0487eaef94f88ef6cc9c8";